export default function About() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-8">Soy Federico Noriega</h2>
          <p className="text-lg text-muted-foreground mb-6">
            Desarrollador de soluciones con datos, automatización e IA aplicada.
          </p>
          <p className="text-lg text-muted-foreground mb-6">
            Ayudo a negocios, profesionales y organizaciones a mejorar procesos, reducir costos 
            y decidir mejor con herramientas simples pero inteligentes.
          </p>
          <p className="text-lg font-semibold text-primary">
            Trabajo desde la lógica real del problema, no desde la moda tecnológica.
          </p>
        </div>
      </div>
    </section>
  );
}
