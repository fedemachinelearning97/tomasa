import { Button } from "@/components/ui/button";
import { ClipboardCheck, Eye } from "lucide-react";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="inicio" className="gradient-bg text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center lg:justify-start">
            <img 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400" 
              alt="Federico Noriega - Consultor en Datos e IA" 
              className="rounded-full w-64 h-64 object-cover shadow-2xl border-4 border-white/20" 
            />
          </div>
          
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Soluciones Inteligentes para <span className="text-accent">Optimizar tu Negocio</span>
            </h1>
            <p className="text-xl mb-4 text-blue-100">
              Aplicaciones prácticas con IA, datos reales y automatización útil.
            </p>
            <p className="text-lg mb-8 text-blue-200">
              Transformá tus decisiones y procesos con tecnología aplicada.<br />
              <strong>Sin humo. Sin exceso. Con impacto real.</strong>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={() => scrollToSection('contacto')}
                className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-3 text-base font-semibold"
                size="lg"
              >
                <ClipboardCheck className="mr-2 h-5 w-5" />
                Solicitá un diagnóstico gratis
              </Button>
              <Button 
                onClick={() => scrollToSection('ejemplos')}
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-3 text-base font-semibold"
                size="lg"
              >
                <Eye className="mr-2 h-5 w-5" />
                Mirá ejemplos de lo que hago
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
