import { Card, CardContent } from "@/components/ui/card";
import { Target, Settings, TrendingUp } from "lucide-react";

const projects = [
  {
    title: "Análisis de Portafolio Financiero con IA",
    description: "Simulador para elegir las mejores acciones basado en análisis predictivo.",
    image: "https://images.unsplash.com/photo-1642790106117-e829e14a795f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    objective: "Optimizar decisiones de inversión",
    technology: "Python, ML, APIs financieras",
    impact: "15% mejora en ROI"
  },
  {
    title: "Dashboard de Precios Locales",
    description: "Precios reales de supermercado con visualización semanal.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    objective: "Comparar precios en tiempo real",
    technology: "Web scraping, Dashboard",
    impact: "20% ahorro en compras"
  },
  {
    title: "Sistema de Turnos Web",
    description: "Sin costos de licencias, adaptable a cualquier profesional.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    objective: "Automatizar agenda médica",
    technology: "React, Node.js, Database",
    impact: "50% menos tiempo administrativo"
  }
];

export default function Examples() {
  return (
    <section id="ejemplos" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Ejemplos Concretos</h2>
          <p className="text-xl text-muted-foreground">Proyectos reales con impacto medible</p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover" 
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-3">{project.title}</h3>
                <p className="text-muted-foreground mb-4">
                  {project.description}
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-accent" />
                    <span className="font-medium">Objetivo:</span>
                    <span className="text-muted-foreground">{project.objective}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Settings className="h-4 w-4 text-accent" />
                    <span className="font-medium">Tecnología:</span>
                    <span className="text-muted-foreground">{project.technology}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-4 w-4 text-accent" />
                    <span className="font-medium">Impacto:</span>
                    <span className="text-muted-foreground">{project.impact}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
