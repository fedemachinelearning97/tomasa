import { CheckCircle } from "lucide-react";

const differentials = [
  "Uso pocos datos pero los convierto en valor.",
  "No necesito sensores ni infraestructuras complejas (¡por ahora!).",
  "Me adapto al problema real de cada cliente.",
  "Entrego sistemas funcionando, no solo \"pruebas de concepto\".",
  "Trabajo con herramientas open source y lógica clara.",
  "Me interesa que aprendas a usar lo que te entrego."
];

export default function Differentials() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">¿Por qué elegirme a mí?</h2>
          <p className="text-xl text-muted-foreground">Diferenciales que hacen la diferencia</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {differentials.map((differential, index) => (
            <div key={index} className="flex items-start space-x-4 p-6 bg-emerald-50 rounded-xl border border-emerald-100">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-emerald-500" />
              </div>
              <p className="text-foreground font-medium">{differential}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-lg font-semibold text-primary max-w-3xl mx-auto">
            Mi meta: que tu negocio sea más eficiente, económico y sostenible con el tiempo.
          </p>
        </div>
      </div>
    </section>
  );
}
