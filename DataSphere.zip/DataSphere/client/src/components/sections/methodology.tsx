const steps = [
  {
    number: 1,
    title: "Diagnóstico",
    description: "Analizo tu situación y te propongo mejoras concretas."
  },
  {
    number: 2,
    title: "Prototipo",
    description: "Desarrollo una aplicación funcional, sin exceso."
  },
  {
    number: 3,
    title: "Entrega",
    description: "Te muestro cómo usarla."
  },
  {
    number: 4,
    title: "Mejora",
    description: "Con tu feedback, se optimiza o escalan las funciones."
  }
];

export default function Methodology() {
  return (
    <section id="metodologia" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Cómo Trabajo</h2>
          <p className="text-xl text-muted-foreground">Metodología sin vueltas</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="bg-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-white text-2xl font-bold">
                {step.number}
              </div>
              <h3 className="text-xl font-bold text-foreground mb-4">{step.title}</h3>
              <p className="text-muted-foreground">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
