import { Card, CardContent } from "@/components/ui/card";
import { 
  TrendingUp, 
  Smartphone, 
  Bot, 
  Gem, 
  Shield, 
  Brain 
} from "lucide-react";

const services = [
  {
    icon: TrendingUp,
    title: "Tableros de Control",
    description: "Visualizo tus datos y KPI para tomar decisiones claras.",
    example: "Panel de ventas y horarios para comercio local."
  },
  {
    icon: Smartphone,
    title: "Apps de Control",
    description: "Reemplazo planillas desordenadas por apps simples con base de datos.",
    example: "Sistema de turnos web para consultorio."
  },
  {
    icon: Bot,
    title: "Automatización",
    description: "Bots, recordatorios, respuestas automáticas, informes.",
    example: "Agenda de turnos + recordatorios por mail."
  },
  {
    icon: Gem,
    title: "Análisis Predictivo",
    description: "Modelos que anticipan tendencias o fallos.",
    example: "Predicción de ventas mensuales y recomendaciones."
  },
  {
    icon: Shield,
    title: "Ciberseguridad Básica",
    description: "Diagnóstico de seguridad + buenas prácticas automatizadas.",
    example: "Control de accesos y backups para consultorio."
  },
  {
    icon: Brain,
    title: "IA Aplicada",
    description: "Agrupación de clientes, análisis de texto, chatbots de soporte.",
    example: "Segmentación de clientes + chatbot de ayuda."
  }
];

export default function Services() {
  return (
    <section id="servicios" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Servicios Estructurados</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Soluciones concretas para problemas reales, adaptadas a las necesidades específicas de tu negocio.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="service-card border shadow-lg hover:shadow-xl">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">{service.title}</h3>
                  </div>
                  <p className="text-muted-foreground mb-6">
                    {service.description}
                  </p>
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Ejemplo real:</h4>
                    <p className="text-sm text-muted-foreground">{service.example}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
