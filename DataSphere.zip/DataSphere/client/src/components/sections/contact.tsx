import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Send, 
  MessageCircle, 
  Mail, 
  Calendar,
  Clock,
  CheckCircle,
  Target
} from "lucide-react";

interface ContactFormData {
  name: string;
  email: string;
  company: string;
  message: string;
}

export default function Contact() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: "",
    email: "",
    company: "",
    message: ""
  });

  const { toast } = useToast();

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "¡Mensaje enviado!",
        description: "Te contactaremos pronto para tu diagnóstico gratuito.",
      });
      setFormData({ name: "", email: "", company: "", message: "" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Hubo un problema al enviar tu mensaje. Intentá de nuevo.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completá todos los campos marcados con *",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const openWhatsApp = () => {
    const message = encodeURIComponent('Hola Federico! Me interesa saber más sobre tus servicios de consultoría en datos e IA.');
    window.open(`https://wa.me/1234567890?text=${message}`, '_blank');
  };

  return (
    <section id="contacto" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            ¿Tenés un problema con tus datos, decisiones o procesos?
          </h2>
          <p className="text-xl text-accent font-semibold">
            Te ayudo a resolverlo con tecnología útil y clara.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="shadow-lg">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-foreground mb-6">Reservá un diagnóstico sin cargo</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="name" className="text-sm font-medium text-foreground mb-2 block">
                    Nombre completo *
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Tu nombre"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="email" className="text-sm font-medium text-foreground mb-2 block">
                    Email *
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="tu@email.com"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="company" className="text-sm font-medium text-foreground mb-2 block">
                    Empresa/Organización
                  </Label>
                  <Input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Nombre de tu empresa"
                  />
                </div>
                
                <div>
                  <Label htmlFor="message" className="text-sm font-medium text-foreground mb-2 block">
                    Contanos tu desafío *
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Describí brevemente qué problema necesitás resolver..."
                    required
                    className="resize-none"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  disabled={contactMutation.isPending}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  size="lg"
                >
                  <Send className="mr-2 h-5 w-5" />
                  {contactMutation.isPending ? "Enviando..." : "Enviar solicitud de diagnóstico"}
                </Button>
              </form>
            </CardContent>
          </Card>
          
          {/* Direct Contact Options */}
          <div className="space-y-8">
            <Card className="shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-foreground mb-6">Contacto Directo</h3>
                
                <div className="space-y-4">
                  <button
                    onClick={openWhatsApp}
                    className="flex items-center space-x-4 p-4 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors border border-emerald-200 w-full text-left"
                  >
                    <div className="bg-emerald-500 w-12 h-12 rounded-full flex items-center justify-center">
                      <MessageCircle className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">WhatsApp</h4>
                      <p className="text-muted-foreground">Conversemos directamente</p>
                    </div>
                  </button>
                  
                  <a
                    href="mailto:federico@fndevapplied.com"
                    className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors border border-blue-200"
                  >
                    <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">Email</h4>
                      <p className="text-muted-foreground">federico@fndevapplied.com</p>
                    </div>
                  </a>
                  
                  <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg border">
                    <div className="bg-muted-foreground w-12 h-12 rounded-full flex items-center justify-center">
                      <Calendar className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">Horarios</h4>
                      <p className="text-muted-foreground">Lun-Vie 9:00-18:00 (UTC-3)</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Quick Stats */}
            <Card className="gradient-bg text-white shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold mb-6">Respuesta garantizada</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-accent">24h</div>
                    <div className="text-sm text-blue-200">Respuesta inicial</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">48h</div>
                    <div className="text-sm text-blue-200">Diagnóstico básico</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">100%</div>
                    <div className="text-sm text-blue-200">Sin compromiso</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
